package com.colang.testapp.model;

/**
 * Created by akshay on 13/6/17.
 */

public class Video {
}
