package com.colang.testapp.adapter;

import android.content.Context;
import android.os.Parcelable;
import android.support.v4.view.PagerAdapter;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

/**
 * Created by akshay on 13/6/17.
 */

public class ImageSliderAdapter extends PagerAdapter {

    private Context context;
//    list of images : eg- List<Image> images;

    // pass list of images inside constructor as second parameter
    public ImageSliderAdapter(Context context) {
        this.context = context;
//        this.images = images
    }

    @Override
    public int getCount() {
//        return images.size();
        return 5;
    }

    @Override
    public Object instantiateItem(ViewGroup container, int position) {
        TextView textView = new TextView(context);
        textView.setGravity(Gravity.CENTER);
        textView.setText("Pushpa + Anjali = Pushpanjali");

//        add code to display images here

        container.addView(textView);
        return textView;
    }

    @Override
    public void destroyItem(ViewGroup container, int position, Object object) {
        container.removeView((View) object);
    }

    @Override
    public boolean isViewFromObject(View view, Object object) {
        return view == object;
    }

    @Override
    public void restoreState(Parcelable arg0, ClassLoader arg1) {
    }

    @Override
    public Parcelable saveState() {
        return null;
    }
}
