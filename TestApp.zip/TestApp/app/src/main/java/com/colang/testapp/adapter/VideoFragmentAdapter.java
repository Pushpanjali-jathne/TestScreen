package com.colang.testapp.adapter;

import android.content.Context;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import com.colang.testapp.R;
import com.colang.testapp.model.Video;

import java.util.List;

/**
 * Created by akshay on 13/6/17.
 */

public class VideoFragmentAdapter extends RecyclerView.Adapter<VideoFragmentAdapter.ViewHolder> {

    private Context context;
    private List<Video> videos;

    public VideoFragmentAdapter(Context context, List<Video> videos) {
        this.context = context;
        this.videos = videos;
    }

    @Override
    public ViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.video_fragment_row_layout,
                parent, false);
        return new ViewHolder(view);
    }

    @Override
    public void onBindViewHolder(ViewHolder holder, int position) {
//        Video video = videos.get(position);
        //add values to views here
        // eg : holder.titleTextview.setText(text);

    }

    @Override
    public int getItemCount() {
        // remove comment later
//        return videos.size();
        return 5;
    }

    public class ViewHolder extends RecyclerView.ViewHolder {

        private ImageView imageView;
        private TextView titleTextview;
        private TextView timeTextview;
        private TextView descriptionTextview;

        public ViewHolder(View itemView) {
            super(itemView);

            imageView = (ImageView) itemView.findViewById(R.id.imageview);
            titleTextview = (TextView) itemView.findViewById(R.id.title);
            timeTextview = (TextView) itemView.findViewById(R.id.time_text);
            descriptionTextview = (TextView) itemView.findViewById(R.id.description_text);
        }
    }
}
